# Return an int array length 3 containing the first 3 digits of pi, {3, 1, 4}.


# make_pi() → [3, 1, 4]

def make_pi():
    return [3, 1, 4]
