x = int(input())
y = int(input())
if (x != 1 and y != 1) or (x == 1 and y == 1):
    print("YES")
else:
    print("NO")
