a = int(input())
n = 1
res = 1
while res <= a:
    print(res)
    n += 1
    res = pow(n, 2)
