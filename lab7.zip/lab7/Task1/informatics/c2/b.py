a = int(input())
b = 2
while 1:
    if a % b == 0:
        print(b)
        break
    b += 1
