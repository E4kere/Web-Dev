a = int(input())
n = 1
while n < a:
    n *= 2
if n == a:
    print("YES")
else:
    print("NO")
