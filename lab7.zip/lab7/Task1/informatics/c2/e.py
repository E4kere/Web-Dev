a = int(input())
n = 1
k = 0
while n < a:
    n *= 2
    k += 1
print(k)
